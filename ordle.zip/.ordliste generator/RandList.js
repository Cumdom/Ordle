var ararar = []
OL.forEach(x => {ararar.splice(Math.floor(ararar.length*Math.random()), 0, x);})

console.log(ararar)
